

  **Markdown**

  ```markdown
[![GitHub Clones](https://img.shields.io/badge/dynamic/json?color=success&label=Clone&query=count&url=https://gist.githubusercontent.com/YaqiangCao/3e13bd554104e813cad0dc10413389c3/raw/clone.json&logo=github)](https://github.com/MShawon/github-clone-count-badge)

  ```

  **HTML**
  ```html
<a href='https://github.com/MShawon/github-clone-count-badge'><img alt='GitHub Clones' src='https://img.shields.io/badge/dynamic/json?color=success&label=Clone&query=count&url=https://gist.githubusercontent.com/YaqiangCao/3e13bd554104e813cad0dc10413389c3/raw/clone.json&logo=github'></a>
```
